/***
 * Classe de l'objet arme
 */
export class Arme{
  id: number;
  name: string;
  attaque:number;
  defense:number;
  PV:number;
  Esquive:number;
  Heroes:number[];
}
