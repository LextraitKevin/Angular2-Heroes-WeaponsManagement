export class Hero {
  id: number;
  name: string;
  attaque:number;
  defense:number;
  PV:number;
  Esquive:number;
  Arme:number;
  nbClick:number;
}
